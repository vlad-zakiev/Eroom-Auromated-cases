<?php

/***
 * @deprecated 3.0
 */

if ( ! class_exists( 'STM_LMS_Settings' ) ) {
	class STM_LMS_Settings {
		static function stm_get_post_type_array() {
		}
	}
}
