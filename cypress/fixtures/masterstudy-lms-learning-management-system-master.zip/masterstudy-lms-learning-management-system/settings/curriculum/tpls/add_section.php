<div class="add_section" @click="addSection">
    <i class="fa fa-plus"></i>
    <?php esc_html_e('New section', 'masterstudy-lms-learning-management-system'); ?>
</div>