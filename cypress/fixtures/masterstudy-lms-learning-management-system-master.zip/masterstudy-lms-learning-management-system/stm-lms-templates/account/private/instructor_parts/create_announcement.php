<?php
/**
 * @var $current_user
 */

do_action('stm_lms_create_announcement', $current_user);