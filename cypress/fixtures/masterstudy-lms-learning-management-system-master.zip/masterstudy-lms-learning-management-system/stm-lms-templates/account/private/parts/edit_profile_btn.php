<?php
/**
 * @var $current_user
 */
?>

<div class="stm-lms-user_edit_profile_btn" data-container=".stm_lms_edit_account">
	<a href="#">
        <i class="fa fa-cog"></i>
        <span><?php esc_html_e('Edit profile', 'masterstudy-lms-learning-management-system'); ?></span>
    </a>
</div>