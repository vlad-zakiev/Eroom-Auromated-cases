<transition name="slide">
    <div>

        <a href="#" class="back" @click.prevent="goBack()">
            <?php esc_html_e('Back', 'masterstudy-lms-learning-management-system'); ?>
        </a>

<!--        <div class="lms_breadcrumb">-->
<!--            <div class="crumb">-->
<!--                <a href="#">Home</a>-->
<!--            </div>-->
<!--            <div class="crumb">-->
<!--                <a href="#">Students</a>-->
<!--            </div>-->
<!--        </div>-->


    </div>
</transition>