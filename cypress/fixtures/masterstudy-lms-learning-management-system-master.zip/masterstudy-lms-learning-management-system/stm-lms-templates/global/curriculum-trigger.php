<?php
stm_lms_register_style('curriculum_trigger');
stm_lms_register_script('curriculum_trigger');
?>

<div class="stm-lms-curriculum-trigger">
	<i class="fa fa-list-ul"></i>
</div>
