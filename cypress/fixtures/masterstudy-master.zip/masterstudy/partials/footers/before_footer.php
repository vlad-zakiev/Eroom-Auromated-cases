<?php
/**
 * Here we are closing two tags from header #main and #wrapper. Footer should stand all alone for fixed position below main site
 */

?>
   </div>
</div>