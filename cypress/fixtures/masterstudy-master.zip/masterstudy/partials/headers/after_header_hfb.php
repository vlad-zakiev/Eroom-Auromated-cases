<?php
/**
 * Closing Page div from HFB
 */
?>
</div> <!--here-->
<div id="main">