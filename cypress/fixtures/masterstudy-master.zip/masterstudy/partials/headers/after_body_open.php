<?php do_action('masterstudy_body_start'); ?>

<div id="wrapper">

    <?php do_action('masterstudy_before_header'); ?>