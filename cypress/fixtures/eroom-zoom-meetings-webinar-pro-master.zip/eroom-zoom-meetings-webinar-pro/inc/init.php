<?php
require_once STM_ZOOM_PRO_PATH . '/classes/StmZoomPro.php';

// Create objects
new StmZoomPro;
